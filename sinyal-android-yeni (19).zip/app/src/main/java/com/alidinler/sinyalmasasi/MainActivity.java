package com.alidinler.sinyalmasasi;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import java.net.URLEncoder;

public class MainActivity extends Activity {
    // Uygulama sayfasi APK'nin icinden bu adresle acilir (gercek bir site degil, telefonun icinde kalir)
    private static final String HOST = Veri.HOST;
    private static final String ADRES = "https://" + HOST + "/";
    private static final String TARAYICI = Veri.TARAYICI;
    private static final String MASAUSTU = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";
    private WebView web;      // bizim uygulama (sinyal paneli, kendi grafigimiz)
    private WebView tv;       // kullanicinin kendi TradingView hesabi
    private LinearLayout kok;
    private boolean tvAcik = false;
    private String tvSon = "";

    @Override
    protected void onCreate(Bundle kayit) {
        super.onCreate(kayit);
        kok = new LinearLayout(this);
        kok.setBackgroundColor(Color.parseColor("#0e131a"));
        tv = new WebView(this);
        web = new WebView(this);
        ayarla(web);
        ayarla(tv);
        tv.setWebChromeClient(new WebChromeClient());
        tv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                // TradingView sayfalari uygulamanin icinde kalir; uygulama acma baglantilari engellenir
                return !("http".equals(sc) || "https".equals(sc));
            }
        });
        kok.addView(tv);
        kok.addView(web);
        setContentView(kok);
        web.addJavascriptInterface(new Kopru(), "SinyalApp");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return Veri.yanit(MainActivity.this, r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (!r.isForMainFrame()) return false;
                Uri u = r.getUrl();
                String host = u.getHost() == null ? "" : u.getHost();
                if (host.equals(HOST)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });
        duzen();
        if (kayit != null) web.restoreState(kayit); else web.loadUrl(ADRES);
        Zamanlayici.iptal(this);
    }

    private void ayarla(WebView w) {
        w.setBackgroundColor(Color.parseColor("#0e131a"));
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
    }

    private boolean genis() {
        return getResources().getConfiguration().screenWidthDp >= 900;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // Tablette: solda TradingView, sagda sinyal paneli. Telefonda: ustte TradingView, altta panel.
    private void duzen() {
        boolean g = genis();
        kok.setOrientation(g ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        tv.setVisibility(tvAcik ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams lt, lw;
        if (g) {
            lt = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
            lw = tvAcik ? new LinearLayout.LayoutParams(dp(430), ViewGroup.LayoutParams.MATCH_PARENT)
                        : new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        } else {
            lt = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.3f);
            lw = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        }
        tv.setLayoutParams(lt);
        web.setLayoutParams(lw);
        tv.getSettings().setUserAgentString(g ? MASAUSTU : TARAYICI);
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        duzen();
    }

    // Uygulama sayfasindan cagrilir: TradingView'i ac/kapat ve urunu degistir
    private class Kopru {
        @JavascriptInterface
        public void tvModu(final boolean ac) {
            runOnUiThread(() -> { tvAcik = ac; duzen(); });
        }

        // TradingView'i telefonun kendi tarayicisinda acar (orada Google ile giris calisir);
        // uygulama bolunmus ekrandaysa tarayici diger yarida acilir
        @JavascriptInterface
        public void tarayicidaAc(final String url) {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT);
                    startActivity(i);
                } catch (Exception e) { }
            });
        }

        @JavascriptInterface
        public void tvSembol(final String sembol, final String aralik) {
            runOnUiThread(() -> {
                try {
                    String u = "https://www.tradingview.com/chart/?symbol=" + URLEncoder.encode(sembol, "UTF-8")
                            + "&interval=" + URLEncoder.encode(aralik, "UTF-8");
                    if (!u.equals(tvSon)) { tvSon = u; tv.loadUrl(u); }
                } catch (Exception e) { }
            });
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle cikis) {
        super.onSaveInstanceState(cikis);
        web.saveState(cikis);
    }

    @Override
    public void onBackPressed() {
        if (tvAcik && tv.canGoBack()) tv.goBack();
        else if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
