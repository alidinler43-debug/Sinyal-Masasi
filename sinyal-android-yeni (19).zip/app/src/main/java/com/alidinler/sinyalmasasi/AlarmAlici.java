package com.alidinler.sinyalmasasi;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// Eski surumden kalan bir alarm calarsa hicbir sey taramaz, sadece alarmlari kapatir
public class AlarmAlici extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent in) {
        Zamanlayici.iptal(ctx);
    }
}
