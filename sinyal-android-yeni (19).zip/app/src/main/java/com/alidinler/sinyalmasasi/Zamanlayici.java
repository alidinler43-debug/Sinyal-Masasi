package com.alidinler.sinyalmasasi;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

// Eski surumun kurdugu tarama alarmlarini iptal eder (uygulama artik kendi verisiyle tarama yapmiyor;
// alarmlar TradingView'daki Sinyal Masasi gostergesinden gelir)
final class Zamanlayici {
    static final String TARA = "com.alidinler.sinyalmasasi.TARA";

    private Zamanlayici() { }

    static void iptal(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int i = 0; i < 3; i++) {
            Intent in = new Intent(ctx, AlarmAlici.class);
            in.setAction(TARA);
            PendingIntent pi = PendingIntent.getBroadcast(ctx, 500 + i, in,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
            pi.cancel();
        }
    }
}
