package com.alidinler.sinyalmasasi;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    // Uygulama sayfasi APK'nin icinden bu adresle acilir (gercek bir site degil, telefonun icinde kalir)
    private static final String HOST = "appassets.androidplatform.net";
    private static final String ADRES = "https://" + HOST + "/";
    private static final String TARAYICI = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";
    private WebView web;

    @Override
    protected void onCreate(Bundle kayit) {
        super.onCreate(kayit);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0e131a"));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String yol = u.getEncodedPath();
                if (yol == null || yol.length() == 0) yol = "/";
                try {
                    if (yol.equals("/") || yol.equals("/index.html")) {
                        return new WebResourceResponse("text/html", "utf-8", getAssets().open("index.html"));
                    }
                    String hedef = null;
                    if (yol.startsWith("/yahoo1/")) hedef = "https://query1.finance.yahoo.com/" + yol.substring(8);
                    else if (yol.startsWith("/yahoo2/")) hedef = "https://query2.finance.yahoo.com/" + yol.substring(8);
                    else if (yol.startsWith("/bf/")) hedef = "https://fapi.binance.com/" + yol.substring(4);
                    if (hedef != null) {
                        String sorgu = u.getEncodedQuery();
                        if (sorgu != null) hedef = hedef + "?" + sorgu;
                        return getir(hedef);
                    }
                } catch (Exception e) {
                    return hata(502, "Bad Gateway");
                }
                return hata(404, "Not Found");
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (!r.isForMainFrame()) return false;
                Uri u = r.getUrl();
                String host = u.getHost() == null ? "" : u.getHost();
                if (host.equals(HOST)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });
        if (kayit != null) web.restoreState(kayit); else web.loadUrl(ADRES);
    }

    // Fiyat verisini telefonun kendi internetiyle Yahoo'dan ceker (tarayici engeli yok)
    private WebResourceResponse getir(String adres) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(adres).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(25000);
            c.setRequestProperty("User-Agent", TARAYICI);
            c.setRequestProperty("Accept", "application/json");
            int kod = c.getResponseCode();
            InputStream in = kod >= 400 ? c.getErrorStream() : c.getInputStream();
            byte[] veri = oku(in);
            if (kod >= 300 && kod < 400) kod = 502;
            Map<String, String> h = new HashMap<>();
            h.put("Access-Control-Allow-Origin", "*");
            h.put("Cache-Control", "no-store");
            return new WebResourceResponse("application/json", "utf-8", kod, kod == 200 ? "OK" : "Hata", h, new ByteArrayInputStream(veri));
        } catch (Exception e) {
            return hata(502, "Bad Gateway");
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static byte[] oku(InputStream in) throws IOException {
        if (in == null) return new byte[0];
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[16384];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        in.close();
        return o.toByteArray();
    }

    private static WebResourceResponse hata(int kod, String neden) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse("text/plain", "utf-8", kod, neden, h, new ByteArrayInputStream(new byte[0]));
    }

    @Override
    protected void onSaveInstanceState(Bundle cikis) {
        super.onSaveInstanceState(cikis);
        web.saveState(cikis);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
