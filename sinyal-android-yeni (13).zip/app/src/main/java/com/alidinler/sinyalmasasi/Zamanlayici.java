package com.alidinler.sinyalmasasi;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;
import java.util.TimeZone;

// Her piyasanin gunluk kapanisindan 2 saat once taramayi baslatan alarmlar
final class Zamanlayici {
    static final String TARA = "com.alidinler.sinyalmasasi.TARA";
    // grup, saat dilimi, alarm saati (kapanistan 2 saat once), hafta sonu da calisir mi
    // hisse: 16:00 New York kapanisi -> 14:00 | emtia (altin, gumus): 17:00 -> 15:00 | koin: 00:00 UTC -> 22:00
    static final String[][] PLAN = {
            {"hisse", "America/New_York", "14", "0"},
            {"emtia", "America/New_York", "15", "0"},
            {"koin", "UTC", "22", "1"}
    };

    private Zamanlayici() { }

    static void kur(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int i = 0; i < PLAN.length; i++) {
            String[] p = PLAN[i];
            long t = sonraki(p[1], Integer.parseInt(p[2]), "1".equals(p[3]), System.currentTimeMillis());
            Intent in = new Intent(ctx, AlarmAlici.class);
            in.setAction(TARA);
            in.putExtra("grup", p[0]);
            PendingIntent pi = PendingIntent.getBroadcast(ctx, 500 + i, in,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                }
            } catch (SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
            }
        }
    }

    static long sonraki(String tz, int saat, boolean haftaSonu, long simdi) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone(tz));
        c.setTimeInMillis(simdi);
        c.set(Calendar.HOUR_OF_DAY, saat);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= simdi + 30000) c.add(Calendar.DAY_OF_MONTH, 1);
        while (!haftaSonu && (c.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || c.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)) {
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        return c.getTimeInMillis();
    }
}
