package com.alidinler.sinyalmasasi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Guclu AL (5. ve 4. derece) bildirimleri: titresimli, uygulamaya dokununca acilir
final class Bildirim {
    static final String KANAL = "guclu_al";
    static final long[] TITRESIM = {0, 400, 200, 400, 200, 700};

    private Bildirim() { }

    static void kanal(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(KANAL) != null) return;
        NotificationChannel ch = new NotificationChannel(KANAL, "Güçlü AL sinyalleri", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("5. ve 4. derece AL gelmek üzereyken, günlük kapanıştan 2 saat önce");
        ch.enableVibration(true);
        ch.setVibrationPattern(TITRESIM);
        nm.createNotificationChannel(ch);
    }

    static void goster(Context ctx, String json) {
        boolean test = false;
        try {
            JSONObject o = new JSONObject(json);
            test = o.optBoolean("test", false);
            JSONArray hits = o.optJSONArray("hits");
            Map<String, List<String>> urunler = new LinkedHashMap<>();
            if (hits != null) {
                for (int i = 0; i < hits.length(); i++) {
                    JSONObject x = hits.getJSONObject(i);
                    String satir = x.optString("tfn") + " " + x.optString("ind") + " · " + x.optInt("derece") + ". derece ("
                            + x.optString("renk") + ")" + (x.isNull("lev") ? "" : " · maks " + x.optInt("lev") + "x");
                    String urun = x.optString("urun");
                    List<String> l = urunler.get(urun);
                    if (l == null) {
                        l = new ArrayList<>();
                        urunler.put(urun, l);
                    }
                    l.add(satir);
                }
            }
            int id = 100;
            for (Map.Entry<String, List<String>> e : urunler.entrySet()) {
                gonder(ctx, id++, e.getKey() + ": güçlü AL gelmek üzere", birlestir(e.getValue()));
            }
            if (urunler.isEmpty() && test) {
                String m = "Kontrol edilen: " + liste(o.optJSONArray("checked"))
                        + ". Şu an gelmek üzere 5. veya 4. derece AL yok.";
                JSONArray er = o.optJSONArray("errs");
                if (er != null && er.length() > 0) m += "\nVeri alınamayan: " + liste(er);
                gonder(ctx, 99, "Bildirim testi çalıştı", m);
            }
        } catch (Exception e) {
            if (test) gonder(ctx, 99, "Bildirim testi", "Sonuç okunamadı: " + e.getMessage());
        }
    }

    static void gonder(Context ctx, int id, String baslik, String metin) {
        try {
            kanal(ctx);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            Intent ac = new Intent(ctx, MainActivity.class);
            ac.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(ctx, id, ac, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, KANAL) : new Notification.Builder(ctx);
            b.setSmallIcon(R.drawable.ic_bildirim)
                    .setContentTitle(baslik)
                    .setContentText(ilkSatir(metin))
                    .setStyle(new Notification.BigTextStyle().bigText(metin))
                    .setAutoCancel(true)
                    .setContentIntent(pi);
            if (Build.VERSION.SDK_INT < 26) {
                b.setPriority(Notification.PRIORITY_HIGH);
                b.setVibrate(TITRESIM);
            }
            nm.notify(id, b.build());
        } catch (Exception e) { }
    }

    private static String birlestir(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(s);
        }
        return sb.toString();
    }

    private static String liste(JSONArray a) {
        if (a == null || a.length() == 0) return "-";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(a.optString(i));
        }
        return sb.toString();
    }

    private static String ilkSatir(String m) {
        int i = m.indexOf('\n');
        return i < 0 ? m : m.substring(0, i);
    }
}
