package com.alidinler.sinyalmasasi;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PersistableBundle;

// Alarm calinca (veya telefon yeniden baslayinca) bir sonraki alarmi kurar ve taramayi baslatir
public class AlarmAlici extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent in) {
        Zamanlayici.kur(ctx);
        if (in != null && Zamanlayici.TARA.equals(in.getAction())) {
            isBaslat(ctx, in.getStringExtra("grup"), false);
        }
    }

    static void isBaslat(Context ctx, String grup, boolean test) {
        if (grup == null) grup = "hepsi";
        JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        PersistableBundle pb = new PersistableBundle();
        pb.putString("grup", grup);
        pb.putInt("test", test ? 1 : 0);
        int id = test ? 7000 : ("hisse".equals(grup) ? 7001 : "emtia".equals(grup) ? 7002 : 7003);
        JobInfo ji = new JobInfo.Builder(id, new ComponentName(ctx, TaramaIsi.class))
                .setExtras(pb)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setOverrideDeadline(test ? 5000 : 10 * 60 * 1000)
                .build();
        js.schedule(ji);
    }
}
