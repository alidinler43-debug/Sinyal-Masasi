package com.alidinler.sinyalmasasi;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

// Uygulama kapaliyken: gorunmeyen bir sayfada uygulamanin kendi sinyal hesabini calistirir
public class TaramaIsi extends JobService {
    private final Handler h = new Handler(Looper.getMainLooper());
    private WebView w;
    private JobParameters prm;
    private boolean bitti = false;
    private boolean basladi = false;
    private boolean test = false;

    @Override
    public boolean onStartJob(JobParameters p) {
        prm = p;
        bitti = false;
        basladi = false;
        final String grup = p.getExtras().getString("grup", "hepsi");
        test = p.getExtras().getInt("test", 0) == 1;
        try {
            w = new WebView(getApplicationContext());
            WebSettings s = w.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            w.addJavascriptInterface(new Kopru(), "SinyalBG");
            w.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                    return Veri.yanit(TaramaIsi.this, r.getUrl());
                }

                @Override
                public void onPageFinished(WebView v, String url) {
                    if (basladi) return;
                    basladi = true;
                    v.evaluateJavascript("taramaYap('" + grup + "'," + (test ? "true" : "false") + ")", null);
                }
            });
            w.loadUrl("https://" + Veri.HOST + "/bg.html");
            h.postDelayed(() -> {
                if (!bitti && test) {
                    Bildirim.gonder(TaramaIsi.this, 99, "Bildirim testi", "Tarama 3 dakikada bitmedi. İnternet bağlantını kontrol et.");
                }
                bitir();
            }, 180000);
        } catch (Throwable t) {
            if (test) Bildirim.gonder(this, 99, "Bildirim testi", "Arka plan taraması başlatılamadı: " + t.getMessage());
            return false;
        }
        return true;
    }

    private class Kopru {
        @JavascriptInterface
        public void bitti(final String json) {
            h.post(() -> {
                if (bitti) return;
                Bildirim.goster(TaramaIsi.this, json);
                bitir();
            });
        }
    }

    private void bitir() {
        if (bitti) return;
        bitti = true;
        h.removeCallbacksAndMessages(null);
        try {
            if (w != null) {
                w.stopLoading();
                w.destroy();
                w = null;
            }
        } catch (Exception e) { }
        jobFinished(prm, false);
    }

    @Override
    public boolean onStopJob(JobParameters p) {
        bitti = true;
        h.removeCallbacksAndMessages(null);
        try {
            if (w != null) {
                w.destroy();
                w = null;
            }
        } catch (Exception e) { }
        return false;
    }
}
