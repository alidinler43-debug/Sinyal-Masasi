package com.alidinler.sinyalmasasi;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

// Uygulama sayfalarini APK'nin icinden verir, fiyat verisini telefonun interneti ile ceker
final class Veri {
    static final String HOST = "appassets.androidplatform.net";
    static final String TARAYICI = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

    private Veri() { }

    static WebResourceResponse yanit(Context ctx, Uri u) {
        if (u == null || !HOST.equals(u.getHost())) return null;
        String yol = u.getEncodedPath();
        if (yol == null || yol.length() == 0) yol = "/";
        try {
            if (yol.equals("/") || yol.equals("/index.html")) {
                return new WebResourceResponse("text/html", "utf-8", ctx.getAssets().open("index.html"));
            }
            if (yol.equals("/bg.html")) {
                return new WebResourceResponse("text/html", "utf-8", ctx.getAssets().open("bg.html"));
            }
            String hedef = null;
            if (yol.startsWith("/yahoo1/")) hedef = "https://query1.finance.yahoo.com/" + yol.substring(8);
            else if (yol.startsWith("/yahoo2/")) hedef = "https://query2.finance.yahoo.com/" + yol.substring(8);
            else if (yol.startsWith("/bf/")) hedef = "https://fapi.binance.com/" + yol.substring(4);
            if (hedef != null) {
                String sorgu = u.getEncodedQuery();
                if (sorgu != null) hedef = hedef + "?" + sorgu;
                return getir(hedef);
            }
        } catch (Exception e) {
            return hata(502, "Bad Gateway");
        }
        return hata(404, "Not Found");
    }

    static WebResourceResponse getir(String adres) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(adres).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(25000);
            c.setRequestProperty("User-Agent", TARAYICI);
            c.setRequestProperty("Accept", "application/json");
            int kod = c.getResponseCode();
            InputStream in = kod >= 400 ? c.getErrorStream() : c.getInputStream();
            byte[] veri = oku(in);
            if (kod >= 300 && kod < 400) kod = 502;
            Map<String, String> h = new HashMap<>();
            h.put("Access-Control-Allow-Origin", "*");
            h.put("Cache-Control", "no-store");
            return new WebResourceResponse("application/json", "utf-8", kod, kod == 200 ? "OK" : "Hata", h, new ByteArrayInputStream(veri));
        } catch (Exception e) {
            return hata(502, "Bad Gateway");
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static byte[] oku(InputStream in) throws IOException {
        if (in == null) return new byte[0];
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[16384];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        in.close();
        return o.toByteArray();
    }

    static WebResourceResponse hata(int kod, String neden) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse("text/plain", "utf-8", kod, neden, h, new ByteArrayInputStream(new byte[0]));
    }
}
