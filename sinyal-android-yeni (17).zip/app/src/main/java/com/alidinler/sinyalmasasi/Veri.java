package com.alidinler.sinyalmasasi;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;

// Uygulama sayfasini APK'nin icinden verir. Uygulama hicbir yerden fiyat verisi cekmez:
// butun fiyatlar ve grafikler TradingView'in kendisinden gelir.
final class Veri {
    static final String HOST = "appassets.androidplatform.net";
    static final String TARAYICI = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

    private Veri() { }

    static WebResourceResponse yanit(Context ctx, Uri u) {
        if (u == null || !HOST.equals(u.getHost())) return null;
        String yol = u.getEncodedPath();
        if (yol == null || yol.length() == 0) yol = "/";
        try {
            if (yol.equals("/") || yol.equals("/index.html")) {
                return new WebResourceResponse("text/html", "utf-8", ctx.getAssets().open("index.html"));
            }
        } catch (Exception e) {
            return hata(500, "Error");
        }
        return hata(404, "Not Found");
    }

    static WebResourceResponse hata(int kod, String neden) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse("text/plain", "utf-8", kod, neden, h, new ByteArrayInputStream(new byte[0]));
    }
}
