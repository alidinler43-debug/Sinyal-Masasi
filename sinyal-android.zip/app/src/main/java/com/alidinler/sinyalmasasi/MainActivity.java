package com.alidinler.sinyalmasasi;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final String ADRES = "https://velvety-valkyrie-eacc21.netlify.app/";
    private static final String CEVRIMDISI = "<html><body style='background:#0e131a;color:#e8edf4;font-family:sans-serif;"
            + "display:flex;align-items:center;justify-content:center;height:100vh;margin:0'><div style='text-align:center'>"
            + "<p style='font-size:18px'>İnternet bağlantısı yok.</p><button onclick=\"location.href='" + ADRES + "'\" "
            + "style='padding:12px 20px;border-radius:10px;border:0;background:#2ebd85;color:#06281c;font-size:16px'>Tekrar dene</button>"
            + "</div></body></html>";
    private WebView web;

    @Override
    protected void onCreate(Bundle kayit) {
        super.onCreate(kayit);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0e131a"));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (!r.isForMainFrame()) return false;
                Uri u = r.getUrl();
                String host = u.getHost() == null ? "" : u.getHost();
                if (host.endsWith("netlify.app")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) v.loadDataWithBaseURL(null, CEVRIMDISI, "text/html", "utf-8", null);
            }
        });
        if (kayit != null) web.restoreState(kayit); else web.loadUrl(ADRES);
    }

    @Override
    protected void onSaveInstanceState(Bundle cikis) {
        super.onSaveInstanceState(cikis);
        web.saveState(cikis);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
