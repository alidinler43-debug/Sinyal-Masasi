using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace SinyalMasasi
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new AnaPencere());
        }
    }

    // Android surumundeki MainActivity'nin Windows karsiligi:
    // solda kullanicinin kendi TradingView hesabi, sagda bizim sinyal paneli / grafigimiz.
    public class AnaPencere : Form
    {
        // Sayfalar exe'nin icinden bu adresle acilir (gercek bir site degil, bilgisayarin icinde kalir).
        // Android ile ayni adres: kayitli veriler sayfa kodunda ayni sekilde calisir.
        const string HOST = "appassets.androidplatform.net";
        const string ADRES = "https://" + HOST + "/";
        const string SURUM = "Windows 1.0";
        const string TARAYICI = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";
        static readonly Color ZEMIN = Color.FromArgb(0x0e, 0x13, 0x1a);
        static readonly HttpClient Http = YeniHttp();

        // Sayfa kodu Android'deki window.SinyalApp koprusunu kullanir; burada ayni isimlerle kurulur.
        const string KOPRU = @"(function(){
  try{ if(location.hostname!=='appassets.androidplatform.net'||window.top!==window) return; }catch(e){ return; }
  var g=function(f,a){ try{ window.chrome.webview.postMessage(JSON.stringify({f:f,a:a})); }catch(e){} };
  window.SinyalApp={
    tvModu:function(b){ g('tvModu',[!!b]); },
    tvSembol:function(s,i){ g('tvSembol',[String(s),String(i)]); },
    tarayicidaAc:function(u){ g('tarayicidaAc',[String(u)]); }
  };
})();";

        readonly WebView2 tv = new WebView2();   // kullanicinin kendi TradingView hesabi
        readonly WebView2 web = new WebView2();  // bizim uygulama (sinyal paneli, kendi grafigimiz)
        readonly Splitter ayrac = new Splitter();
        CoreWebView2Environment ortam;
        bool tvAcik = false;
        string tvSon = "";
        int panelGen = 0;

        public AnaPencere()
        {
            Text = "Sinyal Masası (" + SURUM + ")";
            BackColor = ZEMIN;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1400, 860);
            WindowState = FormWindowState.Maximized;
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            tv.DefaultBackgroundColor = ZEMIN;
            web.DefaultBackgroundColor = ZEMIN;
            web.Dock = DockStyle.Right;
            web.Width = 470;
            ayrac.Dock = DockStyle.Right;
            ayrac.Width = 5;
            ayrac.BackColor = Color.FromArgb(0x2a, 0x2e, 0x39);
            ayrac.MinSize = 300;
            ayrac.MinExtra = 300;
            tv.Dock = DockStyle.Fill;

            // Siralama onemli: once sagdaki panel, sonra ayrac, en son kalan alani dolduran TradingView
            Controls.Add(web);
            Controls.Add(ayrac);
            Controls.Add(tv);
            tv.BringToFront();

            Load += async (s, e) => await Baslat();
        }

        async Task Baslat()
        {
            try
            {
                // Giris bilgileri, kayitlar ve ayarlar burada saklanir (exe nereye konursa konsun)
                string klasor = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SinyalMasasi");
                Directory.CreateDirectory(klasor);
                ortam = await CoreWebView2Environment.CreateAsync(null, klasor);
                await web.EnsureCoreWebView2Async(ortam);
                await tv.EnsureCoreWebView2Async(ortam);
            }
            catch (WebView2RuntimeNotFoundException)
            {
                MessageBox.Show("Bu bilgisayarda Microsoft Edge WebView2 bulunamadı.\n\nhttps://go.microsoft.com/fwlink/p/?LinkId=2124703 adresinden kurup uygulamayı yeniden açın.",
                    "Sinyal Masası", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Close();
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Uygulama başlatılamadı:\n" + ex.Message, "Sinyal Masası", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
                return;
            }

            CoreWebView2 w = web.CoreWebView2;
            w.Settings.IsStatusBarEnabled = false;
            w.Settings.AreDevToolsEnabled = false;
            w.AddWebResourceRequestedFilter("https://" + HOST + "/*", CoreWebView2WebResourceContext.All);
            w.WebResourceRequested += WebIstek;
            w.WebMessageReceived += WebMesaj;
            // Bizim sayfadan baska bir siteye gidilirse normal tarayicida acilir
            w.NavigationStarting += (s, e) =>
            {
                if (!BizimMi(e.Uri)) { e.Cancel = true; DisaridaAc(e.Uri); }
            };
            w.NewWindowRequested += (s, e) => { e.Handled = true; DisaridaAc(e.Uri); };
            await w.AddScriptToExecuteOnDocumentCreatedAsync(KOPRU);

            CoreWebView2 t = tv.CoreWebView2;
            t.Settings.IsStatusBarEnabled = false;
            // TradingView sayfalari uygulamanin icinde kalir; uygulama acma baglantilari engellenir
            t.NavigationStarting += (s, e) =>
            {
                if (!HttpMi(e.Uri) && !e.Uri.StartsWith("about:", StringComparison.OrdinalIgnoreCase)) e.Cancel = true;
            };
            t.NewWindowRequested += (s, e) =>
            {
                e.Handled = true;
                if (HttpMi(e.Uri)) t.Navigate(e.Uri);
            };

            Duzen();
            w.Navigate(ADRES);
        }

        // TradingView acikken: solda TradingView, sagda panel (aradaki cizgi surukelenerek genislik ayarlanir).
        // Kapaliyken: panel / bizim grafik tum pencereyi kaplar.
        void Duzen()
        {
            SuspendLayout();
            if (tvAcik)
            {
                if (panelGen <= 0) panelGen = LogicalToDeviceUnits(470);
                web.Dock = DockStyle.Right;
                web.Width = Math.Max(300, Math.Min(panelGen, ClientSize.Width - 300));
                tv.Visible = true;
                ayrac.Visible = true;
            }
            else
            {
                if (web.Dock == DockStyle.Right && tv.Visible) panelGen = web.Width;
                tv.Visible = false;
                ayrac.Visible = false;
                web.Dock = DockStyle.Fill;
            }
            ResumeLayout(true);
        }

        // Sayfa kodundan gelen istekler (Android'deki Kopru sinifinin karsiligi)
        void WebMesaj(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            if (!BizimMi(e.Source)) return;
            try
            {
                using (JsonDocument d = JsonDocument.Parse(e.TryGetWebMessageAsString()))
                {
                    string f = d.RootElement.GetProperty("f").GetString();
                    JsonElement a = d.RootElement.GetProperty("a");
                    if (f == "tvModu")
                    {
                        tvAcik = a[0].GetBoolean();
                        Duzen();
                    }
                    else if (f == "tvSembol")
                    {
                        string u = "https://www.tradingview.com/chart/?symbol=" + Uri.EscapeDataString(a[0].GetString() ?? "")
                                 + "&interval=" + Uri.EscapeDataString(a[1].GetString() ?? "D");
                        if (u != tvSon && tv.CoreWebView2 != null) { tvSon = u; tv.CoreWebView2.Navigate(u); }
                    }
                    else if (f == "tarayicidaAc")
                    {
                        DisaridaAc(a[0].GetString());
                    }
                }
            }
            catch { }
        }

        // Sayfalari exe'nin icinden verir; /yahoo1/ ve /yahoo2/ isteklerini ABD hisse/endeks fiyat verisi icin aktarir
        async void WebIstek(object sender, CoreWebView2WebResourceRequestedEventArgs e)
        {
            string adres = e.Request.Uri ?? "";
            string onek = "https://" + HOST;
            if (!adres.StartsWith(onek, StringComparison.OrdinalIgnoreCase)) return;
            string yol = adres.Substring(onek.Length);
            int k = yol.IndexOf('#');
            if (k >= 0) yol = yol.Substring(0, k);
            int q = yol.IndexOf('?');
            string sorgu = q >= 0 ? yol.Substring(q) : "";
            string sade = q >= 0 ? yol.Substring(0, q) : yol;

            if (sade == "" || sade == "/" || sade == "/index.html") { e.Response = Sayfa("index.html"); return; }
            if (sade == "/grafik.html") { e.Response = Sayfa("grafik.html"); return; }

            string hedef = null;
            if (sade.StartsWith("/yahoo1/")) hedef = "https://query1.finance.yahoo.com/" + sade.Substring(8) + sorgu;
            else if (sade.StartsWith("/yahoo2/")) hedef = "https://query2.finance.yahoo.com/" + sade.Substring(8) + sorgu;
            if (hedef == null) { e.Response = Yanit(404, "Not Found", "text/plain", new byte[0]); return; }

            CoreWebView2Deferral ertele = e.GetDeferral();
            try
            {
                int kod;
                byte[] veri;
                try
                {
                    using (HttpRequestMessage istek = new HttpRequestMessage(HttpMethod.Get, hedef))
                    using (HttpResponseMessage cevap = await Http.SendAsync(istek))
                    {
                        kod = (int)cevap.StatusCode;
                        veri = await cevap.Content.ReadAsByteArrayAsync();
                    }
                    if (kod >= 300 && kod < 400) kod = 502;
                }
                catch
                {
                    kod = 502;
                    veri = new byte[0];
                }
                e.Response = Yanit(kod, kod == 200 ? "OK" : "Hata", "application/json", veri);
            }
            catch { }
            finally
            {
                ertele.Complete();
            }
        }

        CoreWebView2WebResourceResponse Sayfa(string ad)
        {
            using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream(ad))
            {
                if (s == null) return Yanit(404, "Not Found", "text/plain", new byte[0]);
                using (MemoryStream m = new MemoryStream())
                {
                    s.CopyTo(m);
                    return Yanit(200, "OK", "text/html", m.ToArray());
                }
            }
        }

        CoreWebView2WebResourceResponse Yanit(int kod, string neden, string tur, byte[] veri)
        {
            string basliklar = "Content-Type: " + tur + "; charset=utf-8\r\n"
                             + "Access-Control-Allow-Origin: *\r\n"
                             + "Cache-Control: no-store";
            return ortam.CreateWebResourceResponse(new MemoryStream(veri), kod, neden, basliklar);
        }

        static HttpClient YeniHttp()
        {
            HttpClientHandler h = new HttpClientHandler { AutomaticDecompression = DecompressionMethods.All };
            HttpClient c = new HttpClient(h) { Timeout = TimeSpan.FromSeconds(25) };
            c.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", TARAYICI);
            c.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "application/json");
            return c;
        }

        static bool HttpMi(string u)
        {
            return u != null && (u.StartsWith("https://", StringComparison.OrdinalIgnoreCase) || u.StartsWith("http://", StringComparison.OrdinalIgnoreCase));
        }

        static bool BizimMi(string u)
        {
            if (string.IsNullOrEmpty(u)) return false;
            if (u.StartsWith("about:", StringComparison.OrdinalIgnoreCase) || u.StartsWith("data:", StringComparison.OrdinalIgnoreCase)) return true;
            try { return string.Equals(new Uri(u).Host, HOST, StringComparison.OrdinalIgnoreCase); }
            catch { return false; }
        }

        // Baglantiyi bilgisayarin normal tarayicisinda acar (orada Google ile giris de calisir)
        static void DisaridaAc(string u)
        {
            if (!HttpMi(u)) return;
            try { Process.Start(new ProcessStartInfo(u) { UseShellExecute = true }); } catch { }
        }
    }
}
